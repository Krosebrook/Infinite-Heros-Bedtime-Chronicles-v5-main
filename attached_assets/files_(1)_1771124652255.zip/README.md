# Infinity Heroes: Bedtime Chronicles

AI-powered interactive bedtime stories for children aged 7–9. Built with React 19, TypeScript, and Google Gemini.

## Quick Start

```bash
npm install
cp .env.example .env    # Add your Gemini API key
npm run dev              # http://localhost:3000
```

Get a Gemini API key at [aistudio.google.com/apikey](https://aistudio.google.com/apikey).

## Story Modes

- **Classic** — Choose-your-own-adventure with hero creation, setting selection, and branching choices
- **Mad Libs** — Fill in silly words, get a hilarious personalized story
- **Sleep** — Hypnotic bedtime mode with ambient soundscapes and gentle narration

## Tech Stack

| Layer | Tech |
|-------|------|
| UI | React 19 + TypeScript + Tailwind CSS |
| Animation | Framer Motion 11 |
| Story Generation | Gemini 3 Pro (structured JSON output) |
| Image Generation | Gemini 2.5 Flash Image |
| TTS Narration | Gemini 2.5 Flash TTS (7 voices) |
| Audio | Web Audio API (procedural soundscapes) |
| Offline Storage | IndexedDB |
| Build | Vite 6 |
| PWA | Service Worker + manifest.json |

## Architecture

```
src/
├── App.tsx                    # Root: lazy loading, error boundaries, settings
├── main.tsx                   # Entry point, SW registration
├── types.ts                   # All TypeScript interfaces
├── index.css                  # Tailwind directives + custom styles
├── components/
│   ├── Setup.tsx              # Setup page container
│   ├── setup/                 # Mode-specific setup wizards
│   ├── reading/               # Reading view + completion screen
│   ├── shared/                # ErrorBoundary, SyncedText, SettingsModal
│   └── ui/                    # LoadingFX, HeroHeader, ApiKeyDialog, Panel, Book
├── hooks/
│   ├── useStoryEngine.ts      # Core state machine (generation, choices, history)
│   ├── useNarrationSync.ts    # Audio playback state sync
│   └── useApiKey.ts           # API key validation
├── services/
│   ├── AIClient.ts            # Gemini API abstraction
│   ├── NarrationManager.ts    # TTS + audio caching
│   └── SoundManager.ts        # Procedural Web Audio soundscapes
└── lib/
    ├── Logger.ts              # Console logging
    └── StorageManager.ts      # IndexedDB persistence
```

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Dev server on port 3000 |
| `npm run build` | TypeScript check + Vite production build |
| `npm run preview` | Preview production build |
| `npm run test` | Run Vitest |
| `npm run lint` | ESLint check |

## Deployment (Replit)

The project includes `.replit` and `replit.nix` configs. Set `VITE_GEMINI_API_KEY` in Replit Secrets, then deploy.

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `VITE_GEMINI_API_KEY` | Yes | Google Gemini API key |

## Build Output

Vite produces optimized chunks with code splitting:
- `vendor` — React core
- `motion` — Framer Motion
- `genai` — Google Generative AI SDK
- `Setup` — Setup view (lazy loaded)
- `ReadingView` — Reading view (lazy loaded)

Total gzipped: ~185 KB JS + 10.7 KB CSS.

## License

Apache-2.0
